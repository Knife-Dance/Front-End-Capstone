# To start the app
start by installing the dependencies by running 'npm run install'
npm run watch

