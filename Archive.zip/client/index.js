console.log("Hello World!");
console.log('knife dance');
import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App.jsx';
import Relate from './components/related/product-card/Related-product.jsx'

ReactDOM.render(<Relate/>, document.getElementById('app'));