Sprint 1
- []
- 1 [x] get pull request from the api
- 2 [x] save it in the sample data
- 3 [x] create the component
- 4 [x] fill it with sample data
- 5 [x] render it on the page
- 6 [] try to render dynamiccly
- 7 [] try to get the the Data dynamiclly